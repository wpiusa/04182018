import React, { Component } from 'react';

class EmployeeList extends Component {
  render(){
  	return(

  	);
  }
}

export default EmployeeList;